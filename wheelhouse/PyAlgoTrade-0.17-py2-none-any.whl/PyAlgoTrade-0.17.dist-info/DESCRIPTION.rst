Python library for backtesting stock trading strategies.


